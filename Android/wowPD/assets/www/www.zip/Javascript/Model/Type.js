﻿(function () {
    var m = window.Model;

    var type = m.Type = function () {
        this.typeID = null;
        this.img = null;



    };


    type.prototype.init = function () {

    };



    /*
  
    静态方法  
    
    */

    type.getOne = function () {
        var t = new type();

    }

})()