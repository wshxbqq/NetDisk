﻿(function () {
    var RT = window.RunTime = {};
    RT.icoPoll = [
    {
        id: "sk1",
        img: "Warlocker/1.png",
        sound: "",
        skill: ""
    },
    {
        id: "sk2",
        img: "Warlocker/2.png",
        sound: "",
        skill: ""
    },
    {
        id: "sk3",
        img: "Warlocker/3.png",
        sound: "",
        skill: ""
    },
    {
        id: "sk4",
        img: "Warlocker/4.png",
        sound: "",
        skill: ""
    },
    {
        id: "sk5",
        img: "Warlocker/5.png",
        sound: "",
        skill: ""
    },
    {
        id: "sk6",
        img: "Warlocker/6.png",
        sound: "",
        skill: ""
    },
    {
        id: "sk7",
        img: "Warlocker/7.png",
        sound: "",
        skill: ""
    }];
    RT.job = "War Locker";
    RT.containerTop;
    RT.containerLeft;
    RT.binggoArray = [];
})()