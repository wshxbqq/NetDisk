﻿(function () {
    window.Model = {};
})()