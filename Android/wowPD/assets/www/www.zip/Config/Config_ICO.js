﻿(function () {
    var icfg = window.ICO_CONFIG = {};
    var wl= icfg.warLocker={};

    wl.sk1={
      id:"sk1",
      img:"Warlocker/1.png",
      sound:"",
      skill:""
    },

    wl.sk2={
      id:"sk2",
      img:"Warlocker/2.png",
      sound:"",
      skill:""
    },

    wl.sk3={
      id:"sk3",
      img:"Warlocker/3.png",
      sound:"",
      skill:""
    },

    wl.sk4={
      id:"sk4",
      img:"Warlocker/4.png",
      sound:"",
      skill:""
    },

    wl.sk5={
      id:"sk5",
      img:"Warlocker/5.png",
      sound:"",
      skill:""
    },

    wl.sk6={
      id:"sk6",
      img:"Warlocker/6.png",
      sound:"",
      skill:""
    },

    wl.sk7={
      id:"sk7",
      img:"Warlocker/7.png",
      sound:"",
      skill: ""
    }
})()