﻿(function () {

    var global = window.GLOBAL_CONFIG = {};
    global.imgPath = "R/Img/";
    global.icoWidth = 100;


    global.startEvent = "touchstart";
    global.moveEvent = "touchmove";
    global.endEvent = "touchend";



//    global.startEvent = "mousedown";
//    global.moveEvent = "mousemove";
//    global.endEvent = "mouseup";
})()